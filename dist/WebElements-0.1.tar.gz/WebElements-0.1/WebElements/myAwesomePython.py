print __file__
