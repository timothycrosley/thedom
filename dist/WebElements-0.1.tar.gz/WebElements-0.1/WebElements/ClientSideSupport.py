"""
    Dummy methods and objects to allow client side python to 'run' serverside
"""

def js(javascript):
    return javascript

class document(object):
    pass
