#!/usr/bin/python
"""
    Contains all elements defined in the standard HTML document object module
"""

from Base import WebElement
import DictUtils
import Factory
from Inputs import ValueElement
from MethodUtils import CallBack

Factory = Factory.Factory("DOM")

class A(WebElement):
    """
        Defines a link that when clicked changes the currently viewed page
    """
    tagName = "a"
    properties = WebElement.properties.copy()
    properties['charset'] = {'action':'attribute'}
    properties['href'] = {'action':'attribute'}
    properties['rel'] = {'action':'attribute'}
    properties['target'] = {'action':'attribute'}

Factory.addProduct(A)


class Abr(WebElement):
    """
        Defines the DOM Abr element
    """
    tagName = "abr"

Factory.addProduct(Abr)


class Address(WebElement):
    """
        Defines the DOM Address element
    """
    tagName = "address"

Factory.addProduct(Address)


class Area(WebElement):
    """
        Defines the DOM Area element
    """
    tagName = "area"

Factory.addProduct(Area)


class Base(WebElement):
    """
        Defines the DOM Base element
    """
    tagName = "base"

Factory.addProduct(Base)


class BDO(WebElement):
    """
        Defines the DOM BDO element
    """
    tagName = "bdo"

Factory.addProduct(BDO)


class BlockQuote(WebElement):
    """
        Defines the DOM BlockQuote element
    """
    tagName = "blockquote"

Factory.addProduct(BlockQuote)


class Body(WebElement):
    """
        Defines the DOM Body element
    """
    tagName = "body"

Factory.addProduct(Body)


class Br(WebElement):
    """
        Defines the DOM Br element
    """
    tagName = "br"
    tagSelfCloses = True
    allowsChildren = False

Factory.addProduct(Br)


class Button(WebElement):
    """
        Defines the DOM Button element
    """
    tagName = "button"

Factory.addProduct(Button)


class Cite(WebElement):
    """
        Defines the DOM Cite element
    """
    tagName = "cite"

Factory.addProduct(Cite)


class Code(WebElement):
    """
        Defines the DOM Code element
    """
    tagName = "code"

Factory.addProduct(Code)


class Col(WebElement):
    """
        Defines the DOM Col element
    """
    tagName = "col"

Factory.addProduct(Col)


class ColGroup(WebElement):
    """
        Defines the DOM ColGroup element
    """
    tagName = "colgroup"

Factory.addProduct(ColGroup)


class DD(WebElement):
    """
        Defines the DOM DD element
    """
    tagName = "dd"

Factory.addProduct(DD)


class Del(WebElement):
    """
        Defines the DOM Del element
    """
    tagName = "del"

Factory.addProduct(Del)


class Dfn(WebElement):
    """
        Defines the DOM Dfn element
    """
    tagName = "dfn"

Factory.addProduct(Dfn)


class Div(WebElement):
    """
        Defines the DOM Div element
    """
    tagName = "div"

Factory.addProduct(Div)


class DL(WebElement):
    """
        Defines the DOM DL element
    """
    tagName = "dl"

Factory.addProduct(DL)


class DT(WebElement):
    """
        Defines the DOM DT element
    """
    tagName = "dt"

Factory.addProduct(DT)


class Em(WebElement):
    """
        Defines the DOM Em element
    """
    tagName = "em"

Factory.addProduct(Em)


class FieldSet(WebElement):
    """
        Defines the DOM FieldSet element
    """
    tagName = "fieldset"

Factory.addProduct(FieldSet)


class Form(WebElement):
    """
        Defines the DOM Form element
    """
    tagName = "form"

Factory.addProduct(Form)


class H1(WebElement):
    """
        Defines the DOM H1 element
    """
    tagName = "h1"

Factory.addProduct(H1)


class H2(WebElement):
    """
        Defines the DOM H2 element
    """
    tagName = "h2"

Factory.addProduct(H2)


class H3(WebElement):
    """
        Defines the DOM H3 element
    """
    tagName = "h3"

Factory.addProduct(H3)


class H4(WebElement):
    """
        Defines the DOM H4 element
    """
    tagName = "h4"

Factory.addProduct(H4)


class H5(WebElement):
    """
        Defines the DOM H5 element
    """
    tagName = "h5"

Factory.addProduct(H5)


class H6(WebElement):
    """
        Defines the DOM H6 element
    """
    tagName = "h6"

Factory.addProduct(H6)


class HR(WebElement):
    """
        Defines the DOM HR element
    """
    tagName = "hr"
    tagSelfCloses = True
    allowsChildren = False

Factory.addProduct(HR)


class HTML(WebElement):
    """
        Defines the DOM HTML element
    """
    tagName = "html"

Factory.addProduct(HTML)


class IFrame(WebElement):
    """
        Defines the DOM IFrame element
    """
    tagName = "iframe"

Factory.addProduct(IFrame)


class Img(WebElement):
    """
        Defines the DOM Image element
    """
    tagName = "img"
    tagSelfCloses = True
    allowsChildren = False

    properties = WebElement.properties.copy()
    properties['src'] = {'action':'attribute'}

Factory.addProduct(Img)


class Input(WebElement):
    """
        Defines the DOM Input element
    """
    tagName = "input"
    tagSelfCloses = True
    allowsChildren = False

Factory.addProduct(Input)


class Ins(WebElement):
    """
        Defines the DOM Ins element
    """
    tagName = "ins"

Factory.addProduct(Ins)


class Kbd(WebElement):
    """
        Defines the DOM Kbd element
    """
    tagName = "kbd"

Factory.addProduct(Kbd)


class Label(WebElement):
    """
        Defines the DOM Label element
    """
    tagName = "label"

Factory.addProduct(Label)


class Legend(WebElement):
    """
        Defines the DOM Legend element
    """
    tagName = "legend"

Factory.addProduct(Legend)


class LI(WebElement):
    """
        Defines the DOM LI element
    """
    tagName = "li"

Factory.addProduct(LI)


class Link(WebElement):
    """
        Defines the DOM Link element
    """
    tagName = "link"
    tagSelfCloses = True
    allowsChildren = False

Factory.addProduct(Link)


class Map(WebElement):
    """
        Defines the DOM Map element
    """
    tagName = "map"

Factory.addProduct(Map)


class Meta(WebElement):
    """
        Defines the DOM Meta element
    """
    tagName = "meta"
    tagSelfCloses = True
    allowsChildren = False

Factory.addProduct(Meta)


class NoScript(WebElement):
    """
        Defines the DOM NoScript element
    """
    tagName = "noscript"

Factory.addProduct(NoScript)


class Object(WebElement):
    """
        Defines the DOM Object element
    """
    tagName = "object"

Factory.addProduct(Object)


class OL(WebElement):
    """
        Defines the DOM OL element
    """
    tagName = "ol"

Factory.addProduct(OL)


class OptGroup(WebElement):
    """
        Defines the DOM OptGroup element
    """
    tagName = "optgroup"

Factory.addProduct(OptGroup)


class Option(WebElement):
    """
        Defines the DOM Option element
    """
    tagName = "option"

Factory.addProduct(Option)


class P(WebElement):
    """
        Defines the DOM P element
    """
    tagName = "p"

Factory.addProduct(P)


class Param(WebElement):
    """
        Defines the DOM Param element
    """
    tagName = "param"
    tagSelfCloses = True
    allowsChildren = False

Factory.addProduct(Param)


class Pre(WebElement):
    """
        Defines the DOM Pre element
    """
    tagName = "pre"

Factory.addProduct(Pre)


class Q(WebElement):
    """
        Defines the DOM Q element
    """
    tagName = "q"

Factory.addProduct(Q)


class Samp(WebElement):
    """
        Defines the DOM Samp element
    """
    tagName = "samp"

Factory.addProduct(Samp)


class Script(WebElement):
    """
        Defines the DOM Script element
    """
    tagName = "script"

Factory.addProduct(Script)


class Select(WebElement):
    """
        Defines the DOM Select element
    """
    tagName = "select"

Factory.addProduct(Select)


class P(WebElement):
    """
        Defines the DOM P element
    """
    tagName = "p"

Factory.addProduct(P)


class Span(WebElement):
    """
        Defines the DOM Span element
    """
    tagName = "span"

Factory.addProduct(Span)


class Strong(WebElement):
    """
        Defines the DOM Strong element
    """
    tagName = "strong"

Factory.addProduct(Strong)


class Style(WebElement):
    """
        Defines the DOM Style element
    """
    tagName = "style"

Factory.addProduct(Style)


class Sub(WebElement):
    """
        Defines the DOM Sub element
    """
    tagName = "sub"

Factory.addProduct(Sub)


class Sup(WebElement):
    """
        Defines the DOM Sup element
    """
    tagName = "sup"

Factory.addProduct(Sup)


class Sup(WebElement):
    """
        Defines the DOM Sup element
    """
    tagName = "sup"

Factory.addProduct(Sup)


class Table(WebElement):
    """
        Defines the DOM Table element
    """
    tagName = "table"

Factory.addProduct(Table)


class TBody(WebElement):
    """
        Defines the DOM TBody element
    """
    tagName = "tbody"

Factory.addProduct(TBody)


class TD(WebElement):
    """
        Defines the DOM TD element
    """
    tagName = "td"

Factory.addProduct(TD)


class TextArea(WebElement):
    """
        Defines the DOM TextArea element
    """
    tagName = "textarea"

Factory.addProduct(TextArea)


class TFoot(WebElement):
    """
        Defines the DOM TFoot element
    """
    tagName = "tfoot"

Factory.addProduct(TFoot)


class TH(WebElement):
    """
        Defines the DOM TH element
    """
    tagName = "th"

Factory.addProduct(TH)


class THead(WebElement):
    """
        Defines the DOM THead element
    """
    tagName = "thead"

Factory.addProduct(THead)


class Title(WebElement):
    """
        Defines the DOM Title element
    """
    tagName = "title"

Factory.addProduct(Title)


class TR(WebElement):
    """
        Defines the DOM TR element
    """
    tagName = "tr"

Factory.addProduct(TR)


class UL(WebElement):
    """
        Defines the DOM UL element
    """
    tagName = "ul"

Factory.addProduct(UL)


class Var(WebElement):
    """
        Defines the DOM Var element
    """
    tagName = "var"

Factory.addProduct(Var)


class Article(WebElement):
    """
        Defines the DOM Article element
    """
    tagName = "article"

Factory.addProduct(Article)


class Aside(WebElement):
    """
        Defines the DOM Aside element
    """
    tagName = "aside"

Factory.addProduct(Aside)


class Audio(WebElement):
    """
        Defines the DOM Audio element
    """
    tagName = "audio"

Factory.addProduct(Audio)


class BDI(WebElement):
    """
        Defines the DOM BDI element
    """
    tagName = "bdi"

Factory.addProduct(BDI)


class Canvas(WebElement):
    """
        Defines the DOM Canvas element
    """
    tagName = "canvas"
    allowsChildren = False

Factory.addProduct(Canvas)


class Command(WebElement):
    """
        Defines the DOM Command element
    """
    tagName = "command"

Factory.addProduct(Command)


class DataList(WebElement):
    """
        Defines the DOM DataList element
    """
    tagName = "datalist"

Factory.addProduct(DataList)


class Details(WebElement):
    """
        Defines the DOM Details element
    """
    tagName = "details"

Factory.addProduct(Details)


class Embed(WebElement):
    """
        Defines the DOM Embed element
    """
    tagName = "embed"

Factory.addProduct(Embed)


class FigCaption(WebElement):
    """
        Defines the DOM FigCaption element
    """
    tagName = "figcaption"

Factory.addProduct(FigCaption)


class Figure(WebElement):
    """
        Defines the DOM Figure element
    """
    tagName = "figure"

Factory.addProduct(Figure)


class Footer(WebElement):
    """
        Defines the DOM Footer element
    """
    tagName = "footer"

Factory.addProduct(Footer)


class Header(WebElement):
    """
        Defines the DOM Header element
    """
    tagName = "header"

Factory.addProduct(Header)


class HGroup(WebElement):
    """
        Defines the DOM HGroup element
    """
    tagName = "hgroup"

Factory.addProduct(HGroup)


class KeyGen(WebElement):
    """
        Defines the DOM KeyGen element
    """
    tagName = "keygen"

Factory.addProduct(KeyGen)


class Mark(WebElement):
    """
        Defines the DOM Mark element
    """
    tagName = "mark"

Factory.addProduct(Mark)


class Meter(WebElement):
    """
        Defines the DOM Meter element
    """
    tagName = "meter"

Factory.addProduct(Meter)


class Nav(WebElement):
    """
        Defines the DOM Nav element
    """
    tagName = "nav"

Factory.addProduct(Nav)


class Output(WebElement):
    """
        Defines the DOM Output element
    """
    tagName = "output"

Factory.addProduct(Output)


class Progress(WebElement):
    """
        Defines the DOM Progress element
    """
    tagName = "progress"

Factory.addProduct(Progress)


class RP(WebElement):
    """
        Defines the DOM RP element
    """
    tagName = "rp"

Factory.addProduct(RP)


class RT(WebElement):
    """
        Defines the DOM RT element
    """
    tagName = "rt"

Factory.addProduct(RT)


class Ruby(WebElement):
    """
        Defines the DOM Ruby element
    """
    tagName = "ruby"

Factory.addProduct(Ruby)


class Section(WebElement):
    """
        Defines the DOM Section element
    """
    tagName = "section"

Factory.addProduct(Section)


class Source(WebElement):
    """
        Defines the DOM Source element
    """
    tagName = "source"

Factory.addProduct(Source)


class Summary(WebElement):
    """
        Defines the DOM Summary element
    """
    tagName = "summary"

Factory.addProduct(Summary)


class Time(WebElement):
    """
        Defines the DOM Time element
    """
    tagName = "time"

Factory.addProduct(Time)


class Track(WebElement):
    """
        Defines the DOM Track element
    """
    tagName = "track"

Factory.addProduct(Track)


class Video(WebElement):
    """
        Defines the DOM Video element
    """
    tagName = "video"

Factory.addProduct(Video)


class Wbr(WebElement):
    """
        Defines the DOM Wbr element
    """
    tagName = "wbr"

Factory.addProduct(Wbr)
