#!/usr/bin/python
"""
    Contains all elements defined in the standard HTML document object module
"""

from Base import WebElement
import DictUtils
import Factory
from Inputs import ValueElement
from MethodUtils import CallBack

Factory = Factory.Factory("DOM")

class A(WebElement):
    """
        Defines a link that when clicked changes the currently viewed page
    """
    __slots__ = ()
    tagName = "a"
    properties = WebElement.properties.copy()
    properties['charset'] = {'action':'attribute'}
    properties['href'] = {'action':'attribute'}
    properties['rel'] = {'action':'attribute'}
    properties['target'] = {'action':'attribute'}

Factory.addProduct(A)


class Abr(WebElement):
    """
        Defines the DOM Abr element
    """
    __slots__ = ()
    tagName = "abr"

Factory.addProduct(Abr)


class Address(WebElement):
    """
        Defines the DOM Address element
    """
    __slots__ = ()
    tagName = "address"

Factory.addProduct(Address)


class Area(WebElement):
    """
        Defines the DOM Area element
    """
    __slots__ = ()
    tagName = "area"

Factory.addProduct(Area)


class Base(WebElement):
    """
        Defines the DOM Base element
    """
    __slots__ = ()
    tagName = "base"

Factory.addProduct(Base)


class BDO(WebElement):
    """
        Defines the DOM BDO element
    """
    __slots__ = ()
    tagName = "bdo"

Factory.addProduct(BDO)


class BlockQuote(WebElement):
    """
        Defines the DOM BlockQuote element
    """
    __slots__ = ()
    tagName = "blockquote"

Factory.addProduct(BlockQuote)


class Body(WebElement):
    """
        Defines the DOM Body element
    """
    __slots__ = ()
    tagName = "body"

Factory.addProduct(Body)


class Br(WebElement):
    """
        Defines the DOM Br element
    """
    __slots__ = ()
    tagName = "br"
    tagSelfCloses = True
    allowsChildren = False

Factory.addProduct(Br)


class Button(WebElement):
    """
        Defines the DOM Button element
    """
    __slots__ = ()
    tagName = "button"

Factory.addProduct(Button)


class Cite(WebElement):
    """
        Defines the DOM Cite element
    """
    __slots__ = ()
    tagName = "cite"

Factory.addProduct(Cite)


class Code(WebElement):
    """
        Defines the DOM Code element
    """
    __slots__ = ()
    tagName = "code"

Factory.addProduct(Code)


class Col(WebElement):
    """
        Defines the DOM Col element
    """
    __slots__ = ()
    tagName = "col"

Factory.addProduct(Col)


class ColGroup(WebElement):
    """
        Defines the DOM ColGroup element
    """
    __slots__ = ()
    tagName = "colgroup"

Factory.addProduct(ColGroup)


class DD(WebElement):
    """
        Defines the DOM DD element
    """
    __slots__ = ()
    tagName = "dd"

Factory.addProduct(DD)


class Del(WebElement):
    """
        Defines the DOM Del element
    """
    __slots__ = ()
    tagName = "del"

Factory.addProduct(Del)


class Dfn(WebElement):
    """
        Defines the DOM Dfn element
    """
    __slots__ = ()
    tagName = "dfn"

Factory.addProduct(Dfn)


class Div(WebElement):
    """
        Defines the DOM Div element
    """
    __slots__ = ()
    tagName = "div"

Factory.addProduct(Div)


class DL(WebElement):
    """
        Defines the DOM DL element
    """
    __slots__ = ()
    tagName = "dl"

Factory.addProduct(DL)


class DT(WebElement):
    """
        Defines the DOM DT element
    """
    __slots__ = ()
    tagName = "dt"

Factory.addProduct(DT)


class Em(WebElement):
    """
        Defines the DOM Em element
    """
    __slots__ = ()
    tagName = "em"

Factory.addProduct(Em)


class FieldSet(WebElement):
    """
        Defines the DOM FieldSet element
    """
    __slots__ = ()
    tagName = "fieldset"

Factory.addProduct(FieldSet)


class Form(WebElement):
    """
        Defines the DOM Form element
    """
    __slots__ = ()
    tagName = "form"

Factory.addProduct(Form)


class H1(WebElement):
    """
        Defines the DOM H1 element
    """
    __slots__ = ()
    tagName = "h1"

Factory.addProduct(H1)


class H2(WebElement):
    """
        Defines the DOM H2 element
    """
    __slots__ = ()
    tagName = "h2"

Factory.addProduct(H2)


class H3(WebElement):
    """
        Defines the DOM H3 element
    """
    __slots__ = ()
    tagName = "h3"

Factory.addProduct(H3)


class H4(WebElement):
    """
        Defines the DOM H4 element
    """
    __slots__ = ()
    tagName = "h4"

Factory.addProduct(H4)


class H5(WebElement):
    """
        Defines the DOM H5 element
    """
    __slots__ = ()
    tagName = "h5"

Factory.addProduct(H5)


class H6(WebElement):
    """
        Defines the DOM H6 element
    """
    __slots__ = ()
    tagName = "h6"

Factory.addProduct(H6)


class HR(WebElement):
    """
        Defines the DOM HR element
    """
    __slots__ = ()
    tagName = "hr"
    tagSelfCloses = True
    allowsChildren = False

Factory.addProduct(HR)


class HTML(WebElement):
    """
        Defines the DOM HTML element
    """
    __slots__ = ()
    tagName = "html"

Factory.addProduct(HTML)


class IFrame(WebElement):
    """
        Defines the DOM IFrame element
    """
    __slots__ = ()
    tagName = "iframe"

Factory.addProduct(IFrame)


class Img(WebElement):
    """
        Defines the DOM Image element
    """
    __slots__ = ()
    tagName = "img"
    tagSelfCloses = True
    allowsChildren = False

    properties = WebElement.properties.copy()
    properties['src'] = {'action':'attribute'}

Factory.addProduct(Img)


class Input(WebElement):
    """
        Defines the DOM Input element
    """
    __slots__ = ()
    tagName = "input"
    tagSelfCloses = True
    allowsChildren = False

Factory.addProduct(Input)


class Ins(WebElement):
    """
        Defines the DOM Ins element
    """
    __slots__ = ()
    tagName = "ins"

Factory.addProduct(Ins)


class Kbd(WebElement):
    """
        Defines the DOM Kbd element
    """
    __slots__ = ()
    tagName = "kbd"

Factory.addProduct(Kbd)


class Label(WebElement):
    """
        Defines the DOM Label element
    """
    __slots__ = ()
    tagName = "label"

Factory.addProduct(Label)


class Legend(WebElement):
    """
        Defines the DOM Legend element
    """
    __slots__ = ()
    tagName = "legend"

Factory.addProduct(Legend)


class LI(WebElement):
    """
        Defines the DOM LI element
    """
    __slots__ = ()
    tagName = "li"

Factory.addProduct(LI)


class Link(WebElement):
    """
        Defines the DOM Link element
    """
    __slots__ = ()
    tagName = "link"
    tagSelfCloses = True
    allowsChildren = False
    properties = WebElement.properties.copy()
    properties['charset'] = {'action':'attribute'}
    properties['src'] = {'action':'attribute'}
    properties['href'] = {'action':'attribute'}
    properties['hreflang'] = {'action':'attribute'}
    properties['media'] = {'action':'attribute'}
    properties['rel'] = {'action':'attribute'}
    properties['rev'] = {'action':'attribute'}
    properties['target'] = {'action':'attribute'}
    properties['type'] = {'action':'attribute'}

Factory.addProduct(Link)


class Map(WebElement):
    """
        Defines the DOM Map element
    """
    __slots__ = ()
    tagName = "map"

Factory.addProduct(Map)


class Meta(WebElement):
    """
        Defines the DOM Meta element
    """
    __slots__ = ()
    tagName = "meta"
    tagSelfCloses = True
    allowsChildren = False

Factory.addProduct(Meta)


class NoScript(WebElement):
    """
        Defines the DOM NoScript element
    """
    __slots__ = ()
    tagName = "noscript"

Factory.addProduct(NoScript)


class Object(WebElement):
    """
        Defines the DOM Object element
    """
    __slots__ = ()
    tagName = "object"

Factory.addProduct(Object)


class OL(WebElement):
    """
        Defines the DOM OL element
    """
    __slots__ = ()
    tagName = "ol"

Factory.addProduct(OL)


class OptGroup(WebElement):
    """
        Defines the DOM OptGroup element
    """
    __slots__ = ()
    tagName = "optgroup"

Factory.addProduct(OptGroup)


class Option(WebElement):
    """
        Defines the DOM Option element
    """
    __slots__ = ()
    tagName = "option"

Factory.addProduct(Option)


class P(WebElement):
    """
        Defines the DOM P element
    """
    __slots__ = ()
    tagName = "p"

Factory.addProduct(P)


class Param(WebElement):
    """
        Defines the DOM Param element
    """
    __slots__ = ()
    tagName = "param"
    tagSelfCloses = True
    allowsChildren = False

Factory.addProduct(Param)


class Pre(WebElement):
    """
        Defines the DOM Pre element
    """
    __slots__ = ()
    tagName = "pre"

Factory.addProduct(Pre)


class Q(WebElement):
    """
        Defines the DOM Q element
    """
    __slots__ = ()
    tagName = "q"

Factory.addProduct(Q)


class Samp(WebElement):
    """
        Defines the DOM Samp element
    """
    __slots__ = ()
    tagName = "samp"

Factory.addProduct(Samp)


class Script(WebElement):
    """
        Defines the DOM Script element
    """
    __slots__ = ()
    tagName = "script"
    properties = WebElement.properties.copy()
    properties['async'] = {'action':'attribute', 'type':'bool'}
    properties['defer'] = {'action':'attribute', 'type':'bool'}
    properties['type'] = {'action':'attribute'}
    properties['charset'] = {'action':'attribute'}
    properties['src'] = {'action':'attribute'}

Factory.addProduct(Script)


class Select(WebElement):
    """
        Defines the DOM Select element
    """
    __slots__ = ()
    tagName = "select"

Factory.addProduct(Select)


class P(WebElement):
    """
        Defines the DOM P element
    """
    __slots__ = ()
    tagName = "p"

Factory.addProduct(P)


class Span(WebElement):
    """
        Defines the DOM Span element
    """
    __slots__ = ()
    tagName = "span"

Factory.addProduct(Span)


class Strong(WebElement):
    """
        Defines the DOM Strong element
    """
    __slots__ = ()
    tagName = "strong"

Factory.addProduct(Strong)


class Style(WebElement):
    """
        Defines the DOM Style element
    """
    __slots__ = ()
    tagName = "style"

Factory.addProduct(Style)


class Sub(WebElement):
    """
        Defines the DOM Sub element
    """
    __slots__ = ()
    tagName = "sub"

Factory.addProduct(Sub)


class Sup(WebElement):
    """
        Defines the DOM Sup element
    """
    __slots__ = ()
    tagName = "sup"

Factory.addProduct(Sup)


class Sup(WebElement):
    """
        Defines the DOM Sup element
    """
    __slots__ = ()
    tagName = "sup"

Factory.addProduct(Sup)


class Table(WebElement):
    """
        Defines the DOM Table element
    """
    __slots__ = ()
    tagName = "table"

Factory.addProduct(Table)


class TBody(WebElement):
    """
        Defines the DOM TBody element
    """
    __slots__ = ()
    tagName = "tbody"

Factory.addProduct(TBody)


class TD(WebElement):
    """
        Defines the DOM TD element
    """
    __slots__ = ()
    tagName = "td"

Factory.addProduct(TD)


class TextArea(WebElement):
    """
        Defines the DOM TextArea element
    """
    __slots__ = ()
    tagName = "textarea"

Factory.addProduct(TextArea)


class TFoot(WebElement):
    """
        Defines the DOM TFoot element
    """
    __slots__ = ()
    tagName = "tfoot"

Factory.addProduct(TFoot)


class TH(WebElement):
    """
        Defines the DOM TH element
    """
    __slots__ = ()
    tagName = "th"

Factory.addProduct(TH)


class THead(WebElement):
    """
        Defines the DOM THead element
    """
    __slots__ = ()
    tagName = "thead"

Factory.addProduct(THead)


class Title(WebElement):
    """
        Defines the DOM Title element
    """
    __slots__ = ()
    tagName = "title"

Factory.addProduct(Title)


class TR(WebElement):
    """
        Defines the DOM TR element
    """
    __slots__ = ()
    tagName = "tr"

Factory.addProduct(TR)


class UL(WebElement):
    """
        Defines the DOM UL element
    """
    __slots__ = ()
    tagName = "ul"

Factory.addProduct(UL)


class Var(WebElement):
    """
        Defines the DOM Var element
    """
    __slots__ = ()
    tagName = "var"

Factory.addProduct(Var)


class Article(WebElement):
    """
        Defines the DOM Article element
    """
    __slots__ = ()
    tagName = "article"

Factory.addProduct(Article)


class Aside(WebElement):
    """
        Defines the DOM Aside element
    """
    __slots__ = ()
    tagName = "aside"

Factory.addProduct(Aside)


class Audio(WebElement):
    """
        Defines the DOM Audio element
    """
    __slots__ = ()
    tagName = "audio"

Factory.addProduct(Audio)


class BDI(WebElement):
    """
        Defines the DOM BDI element
    """
    __slots__ = ()
    tagName = "bdi"

Factory.addProduct(BDI)


class Canvas(WebElement):
    """
        Defines the DOM Canvas element
    """
    __slots__ = ()
    tagName = "canvas"
    allowsChildren = False

Factory.addProduct(Canvas)


class Command(WebElement):
    """
        Defines the DOM Command element
    """
    __slots__ = ()
    tagName = "command"

Factory.addProduct(Command)


class DataList(WebElement):
    """
        Defines the DOM DataList element
    """
    __slots__ = ()
    tagName = "datalist"

Factory.addProduct(DataList)


class Details(WebElement):
    """
        Defines the DOM Details element
    """
    __slots__ = ()
    tagName = "details"

Factory.addProduct(Details)


class Embed(WebElement):
    """
        Defines the DOM Embed element
    """
    __slots__ = ()
    tagName = "embed"

Factory.addProduct(Embed)


class FigCaption(WebElement):
    """
        Defines the DOM FigCaption element
    """
    __slots__ = ()
    tagName = "figcaption"

Factory.addProduct(FigCaption)


class Figure(WebElement):
    """
        Defines the DOM Figure element
    """
    __slots__ = ()
    tagName = "figure"

Factory.addProduct(Figure)


class Footer(WebElement):
    """
        Defines the DOM Footer element
    """
    __slots__ = ()
    tagName = "footer"

Factory.addProduct(Footer)


class Header(WebElement):
    """
        Defines the DOM Header element
    """
    __slots__ = ()
    tagName = "header"

Factory.addProduct(Header)


class HGroup(WebElement):
    """
        Defines the DOM HGroup element
    """
    __slots__ = ()
    tagName = "hgroup"

Factory.addProduct(HGroup)


class KeyGen(WebElement):
    """
        Defines the DOM KeyGen element
    """
    __slots__ = ()
    tagName = "keygen"

Factory.addProduct(KeyGen)


class Mark(WebElement):
    """
        Defines the DOM Mark element
    """
    __slots__ = ()
    tagName = "mark"

Factory.addProduct(Mark)


class Meter(WebElement):
    """
        Defines the DOM Meter element
    """
    __slots__ = ()
    tagName = "meter"

Factory.addProduct(Meter)


class Nav(WebElement):
    """
        Defines the DOM Nav element
    """
    __slots__ = ()
    tagName = "nav"

Factory.addProduct(Nav)


class Output(WebElement):
    """
        Defines the DOM Output element
    """
    __slots__ = ()
    tagName = "output"

Factory.addProduct(Output)


class Progress(WebElement):
    """
        Defines the DOM Progress element
    """
    __slots__ = ()
    tagName = "progress"

Factory.addProduct(Progress)


class RP(WebElement):
    """
        Defines the DOM RP element
    """
    __slots__ = ()
    tagName = "rp"

Factory.addProduct(RP)


class RT(WebElement):
    """
        Defines the DOM RT element
    """
    __slots__ = ()
    tagName = "rt"

Factory.addProduct(RT)


class Ruby(WebElement):
    """
        Defines the DOM Ruby element
    """
    __slots__ = ()
    tagName = "ruby"

Factory.addProduct(Ruby)


class Section(WebElement):
    """
        Defines the DOM Section element
    """
    __slots__ = ()
    tagName = "section"

Factory.addProduct(Section)


class Source(WebElement):
    """
        Defines the DOM Source element
    """
    __slots__ = ()
    tagName = "source"

Factory.addProduct(Source)


class Summary(WebElement):
    """
        Defines the DOM Summary element
    """
    __slots__ = ()
    tagName = "summary"

Factory.addProduct(Summary)


class Time(WebElement):
    """
        Defines the DOM Time element
    """
    __slots__ = ()
    tagName = "time"

Factory.addProduct(Time)


class Track(WebElement):
    """
        Defines the DOM Track element
    """
    __slots__ = ()
    tagName = "track"

Factory.addProduct(Track)


class Video(WebElement):
    """
        Defines the DOM Video element
    """
    __slots__ = ()
    tagName = "video"

Factory.addProduct(Video)


class Wbr(WebElement):
    """
        Defines the DOM Wbr element
    """
    __slots__ = ()
    tagName = "wbr"

Factory.addProduct(Wbr)
