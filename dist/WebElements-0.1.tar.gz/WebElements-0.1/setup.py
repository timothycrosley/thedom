#!/usr/bin/env python

from distutils.core import setup

setup(name='WebElements',
      version='0.1',
      description='Python Distribution Utilities',
      author='Timothy Crosley',
      author_email='timothy.crosley@gmail.com',
      url='http://www.webelements.in/',
      packages=['WebElements',],)
